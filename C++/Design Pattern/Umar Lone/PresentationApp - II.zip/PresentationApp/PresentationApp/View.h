#pragma once
class View
{
public:
	virtual void Display() = 0 ;
	virtual ~View() =default ;
};


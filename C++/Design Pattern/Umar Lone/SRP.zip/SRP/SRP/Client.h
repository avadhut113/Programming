#pragma once
#include "Circle.h"

class Client
{
	Circle	*m_pCircle ;
public:
	
	void UseCircle() ;
};


#include "Line.h"

#include <iostream>

void Line::Render() {
	std::cout << "Rendering line...\n" ;
}

void Line::Erase() {
	std::cout << "Erasing line...\n" ;
}

void Line::Outline() {
	std::cout << "Setting outline for a line...\n" ;
}



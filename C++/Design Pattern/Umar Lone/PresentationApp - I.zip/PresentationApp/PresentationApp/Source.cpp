#include "MainApp.h"
#include "SlideData.h"
#include "SlideShowView.h"

int main() {
	SlideData data{} ;
	SlideShowView ssview{&data} ;
	MainApp app{&data, &ssview} ;

	app.AddSlide() ;

	//app.Load() ;
	//ssview.Display() ;
	//app.ModifySlide() ;

	//ssview.Display() ;

	/*app.AddSlide() ;
	app.Save() ;
	app.Display() ;*/

}

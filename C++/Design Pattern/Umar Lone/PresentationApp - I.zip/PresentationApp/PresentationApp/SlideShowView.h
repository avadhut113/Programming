#pragma once
class SlideData;

class SlideShowView
{
	SlideData *m_pData{} ;
public:
	explicit SlideShowView(SlideData* pData);

	void Display() ;
};


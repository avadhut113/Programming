#include "SlideData.h"

#include <iostream>
#include <fstream>
#include "Slide.h"
void SlideData::Save() {
		std::ofstream out{"deck.txt"} ;
	if(!out) {
		std::cout << "Could not open file for writing\n" ;
		return ;
	}
	for(auto slide:m_Slides) {
		out << slide->GetTitle() << '\n'; 
		out << slide->GetContent() << '\n'; 
		out << slide->GetNotes() << '\n'; 
	}
}

void SlideData::Load() {
	m_Slides.clear() ;
	std::ifstream input{"deck.txt"} ;
	if(!input) {
		std::cout << "Could not open file for reading\n" ;
		return ;
	}

	std::string title{} ;
	std::string content{} ;
	std::string notes{} ;

	do {
		std::getline(input, title) ;
		std::getline(input, content) ;
		std::getline(input, notes) ;
		m_Slides.push_back(new Slide{title, content, notes}) ;
	}while(!input.eof()) ;
}

size_t SlideData::Count() const {
	return m_Slides.size() ;
}

void SlideData::AddSlide(Slide* pSlide) {
	m_Slides.push_back(pSlide) ;
}

void SlideData::RemoveSlide(int index) {
	m_Slides.erase(m_Slides.begin() + index) ;
}

Slide* SlideData::GetSlide(int index) const {
	return m_Slides[index] ;
}

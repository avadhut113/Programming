#pragma once
#include <vector>
class Slide;

class SlideData
{
	std::vector<Slide *> m_Slides{} ;

public:
	void AddSlide(Slide *pSlide) ;
	void RemoveSlide(int index) ;
	Slide * GetSlide(int index)const ;
	void Save() ;
	void Load() ;
	size_t Count()const ;
};


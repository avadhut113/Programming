#pragma once
class View
{
public:
	virtual void Display(int part) = 0 ;
	virtual ~View() =default ;
};


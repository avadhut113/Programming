#pragma once
#include "Observable.h"

class Timer : public Observable
{
public:
	void SimulateTimeChange() ;
};


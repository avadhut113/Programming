#include "Timer.h"

void Timer::SimulateTimeChange() {
	Notify({}) ;
}

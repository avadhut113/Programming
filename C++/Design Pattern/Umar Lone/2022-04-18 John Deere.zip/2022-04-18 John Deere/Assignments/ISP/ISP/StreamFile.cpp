#include "StreamFile.h"

void StreamFile::Open() {
}

void StreamFile::Close() {
}

void StreamFile::Write() {
}

void StreamFile::Read() {
}

void StreamFile::Seek(int position) {
}

size_t StreamFile::GetPosition() const {
	return 150 ;
}

size_t StreamFile::Size() const {
	return 200;
}

#include "TextFile.h"

void TextFile::Open() {
}

void TextFile::Close() {
}

void TextFile::Write() {
}

void TextFile::Read() {
}

void TextFile::Seek(int position) {
}

size_t TextFile::GetPosition() const {
	return 10 ;
}

size_t TextFile::Size() const {
	return 100;
}

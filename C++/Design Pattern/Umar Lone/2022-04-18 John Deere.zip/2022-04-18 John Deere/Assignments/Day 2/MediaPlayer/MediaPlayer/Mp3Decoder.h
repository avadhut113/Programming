#pragma once
#include <string>
class Mp3Decoder 
{
public:
	std::string Decode(const std::string &dataStream);
};


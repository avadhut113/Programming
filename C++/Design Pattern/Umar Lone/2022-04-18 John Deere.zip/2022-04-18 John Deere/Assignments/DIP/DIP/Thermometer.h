#pragma once
class Thermometer
{
public:
	int GetTemperature()const ;
};


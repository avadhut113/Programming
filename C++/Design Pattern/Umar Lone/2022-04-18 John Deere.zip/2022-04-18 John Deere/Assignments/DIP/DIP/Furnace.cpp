#include "Furnace.h"

#include <iostream>

void Furnace::IncreaseTemperature() {
	std::cout << "Increasing temperature\n" ;
}

void Furnace::DecreaseTemperature() {
	std::cout << "Decreasing temperature\n" ;
}

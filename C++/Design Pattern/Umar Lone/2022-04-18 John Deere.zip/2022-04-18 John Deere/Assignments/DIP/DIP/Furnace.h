#pragma once
class Furnace
{
public:
	void IncreaseTemperature() ;
	void DecreaseTemperature() ;
};


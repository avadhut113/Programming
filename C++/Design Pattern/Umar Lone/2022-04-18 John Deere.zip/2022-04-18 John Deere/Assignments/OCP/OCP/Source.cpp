#include "Account.h"

int main() {
	Account acc{SAVINGS,100} ;

}

#include "Lamp.h"

int main() {
	Lamp lamp ;
	lamp.SwitchOn() ;
	lamp.SwitchOn() ;
	lamp.SwitchOn() ;
	lamp.SwitchOn() ;
	lamp.SwitchOff() ;
	lamp.SwitchOff() ;
	lamp.SwitchOff() ;
	lamp.SwitchOff() ;
}

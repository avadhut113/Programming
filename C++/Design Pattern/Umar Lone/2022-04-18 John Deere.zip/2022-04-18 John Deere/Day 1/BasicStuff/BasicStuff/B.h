#pragma once
#include "A.h"
class B :
    public A
{
    int i ;
};


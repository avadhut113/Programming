#include "C.h"

int main() {
	C b ;
}

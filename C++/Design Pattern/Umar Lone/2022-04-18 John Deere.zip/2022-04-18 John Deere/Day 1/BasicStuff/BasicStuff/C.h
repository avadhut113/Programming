#pragma once

class B;

class C
{
	B *b ;
};


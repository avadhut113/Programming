#pragma once
class A
{
	int i ;
};


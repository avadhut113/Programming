#include "Logger.h"

int main() {
	Logger logger ;
	logger.Log("Application has started");
	logger.Log("Application is terminating");
}


